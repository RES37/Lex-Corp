public class PartTimeEmployee extends Employee {
    private static final long serialVersionUID = 1L;

    private double wage;

    void setWage(double ratePerHour, int hoursWorked) { 
        wage = ratePerHour * hoursWorked;
    }

    double getWage() {
        return wage;
    }
}
