import java.io.*;

public class Employee implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String name;

    void setName(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }
}
