import java.io.*;
import java.util.HashMap;
import java.util.Scanner;

public class RunEmployee {
    public static void main(String[] args) {
        // Scanner class
        Scanner sc = new Scanner(System.in);
    
        // Variables
        String name;
        char classification;

        try {
            System.out.println("---------------------------------");
            System.out.println("Simple Employee Payroll");
            System.out.println("---------------------------------");
            System.out.println("Previously added employee: ");
            displayObject();
            System.out.println("---------------------------------");
            System.out.print("Enter name: ");
            name = sc.nextLine();
    
            System.out.print("Press F for Full Time or P for Part Time: ");
            classification = sc.nextLine().charAt(0);
    
            if (classification == 'F' || classification == 'f') {
                // Object
                FullTimeEmployee fte = new FullTimeEmployee();
    
                // Program continues
                fte.setName(name);

                System.out.print("Enter monthly salary: ");
                fte.setMonthlySalary(sc.nextDouble());

                // Serialization
                saveObject(fte);
    
                // Display Output
                System.out.println("---------------------------------");
                displayOutput(fte.getName(), fte.getMonthlySalary());
                System.out.println("---------------------------------");

                System.out.println("Employee added!");
            } else if (classification == 'P' || classification == 'p') {
                // Object
                PartTimeEmployee pte = new PartTimeEmployee();
    
                // Variables
                String[] arr;
    
                // Program continues
                pte.setName(name);

                System.out.print("Enter rate per hour and no. of hours worked separated by space: ");
                arr = sc.nextLine().split(" ");
    
                pte.setWage(Double.parseDouble(arr[0]), Integer.parseInt(arr[1]));

                // Serialization
                saveObject(pte);

                // Display Output
                System.out.println("---------------------------------");
                displayOutput(pte.getName(), pte.getWage());
                System.out.println("---------------------------------");
                
                System.out.println("Employee added!");
            } else {
                System.out.println("Error!");
            }
        } catch(Exception e) {
            System.out.println("Error!");
        } finally {
            sc.close();
        }
    }

    static void saveObject(Object obj) {
        try {
            FileOutputStream fileOut = new FileOutputStream("employee.ser");
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
    
            objectOut.writeObject(obj);
            
            objectOut.close();
            fileOut.close();
        } catch(IOException e) {
            System.out.println("Serialization error!");
        }
    }

    static void displayObject() {
        try {
            FileInputStream fileIn = new FileInputStream("employee.ser");
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);

            // Deserialize object
            Object obj = objectIn.readObject();

            // Check object type and display details accordingly
            if (obj instanceof FullTimeEmployee) {
                FullTimeEmployee fte = (FullTimeEmployee) obj;
                System.out.println("Full Time Employee");
                displayOutput(fte.getName(), fte.getMonthlySalary());
            } else if (obj instanceof PartTimeEmployee) {
                PartTimeEmployee pte = (PartTimeEmployee) obj;
                System.out.println("Part Time Employee");
                displayOutput(pte.getName(), pte.getWage());
            }

            objectIn.close();
            fileIn.close();
        } catch(IOException | ClassNotFoundException e) {
            System.out.println("No employee added yet!");
        }
    }
    
    static void displayOutput(String name, double salary) {
        System.out.println("Name: " + name);
        System.out.println("Salary: " + salary);
    }
}