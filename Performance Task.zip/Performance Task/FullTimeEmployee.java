public class FullTimeEmployee extends Employee {
    private static final long serialVersionUID = 1L;

    private double monthlySalary;

    void setMonthlySalary(double monthlySalary) {
        this.monthlySalary = monthlySalary;
    }

    double getMonthlySalary() {
        return monthlySalary;
    }
}